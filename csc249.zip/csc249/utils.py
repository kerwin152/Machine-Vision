from pathlib import Path

# def tests_save(func, inputs, name):
#     import pickle

#     pairs = []
#     for i in inputs:
#         o = (
#             func(*i)
#             if isinstance(i, list)
#             else func(**i)
#             if isinstance(i, dict)
#             else func(i)
#         )
#         pairs.append({"in": i, "out": o})

#     tests = {"func_name": func.__name__, "pairs": pairs}
#     with open(f"{name}_cases.pkl", mode="wb") as opened_file:
#         print(f"saving {len(inputs)} pairs")
#         pickle.dump(tests, opened_file)


# def tests_load(name):
#     import pickle

#     with open(f"{name}_cases.pkl", mode="rb") as opened_file:
#         tests = pickle.load(opened_file)
#     return tests


# def tests_check(func, tests):
#     assert func.__name__ == tests["func_name"]
#     for pair in tests["pairs"]:
#         i = pair["in"]
#         o = (
#             func(*i)
#             if isinstance(i, list)
#             else func(**i)
#             if isinstance(i, dict)
#             else func(i)
#         )
#         assert np.allclose(o, pair["out"])


# def make_submission(NetID=""):
#     import pathlib, shutil

#     assert NetID.strip(), "Please enter your NetID at the top"
#     print(
#         f"Archived Directory: {pathlib.Path.cwd()}\nPlease summit this saved zip file at"
#     )
#     shutil.make_archive(
#         pathlib.Path.cwd().parent / NetID.lower(), "zip", pathlib.Path.cwd()
#     )


# global info
netid = str(Path.home()).split("/")[-1]
data = Path("/Users/kerwin/courses/449MachineVision/449HW/csc249/data")


# data = Path().home().resolve().parent / "data"
# tensor2numpy = lambda nums, axis: np.stack([i[axis].data.numpy() for i in nums])
import datetime
import pytz

due_date = {
    0: datetime.datetime(
        2022, 1, 21, 23, 59, 59, tzinfo=pytz.timezone("America/New_York")
    ),
    1: datetime.datetime(
        2022, 2, 4, 23, 59, 59, tzinfo=pytz.timezone("America/New_York")
    ),
    2: datetime.datetime(
        2022, 2, 25, 23, 59, 59, tzinfo=pytz.timezone("America/New_York")
    ),
    3: datetime.datetime(
        2022, 3, 25, 23, 59, 59, tzinfo=pytz.timezone("America/New_York")
    ),
}


def time2due(idx):
    if not idx in due_date:
        print("only four assignments we have for this semeter, please use int 0~3")
    diff = due_date[idx] - datetime.datetime.now(tz=pytz.timezone("America/New_York"))
    if diff.days < 0:
        print("The assignment {idx} is past due")
    else:
        remain = {
            "d": diff.days,
            "h": diff.seconds // 3600,
            "m": diff.seconds % 3600 // 60,
        }
        print(
            f'Still have {":".join([f"{v}{k}" for k,v in remain.items() if v!=0])} for assignment {idx}'
        )


def make_submission():
    import pathlib, shutil
    from zipfile import ZipFile

    saved = f"{pathlib.Path.cwd()/netid}.zip"
    with ZipFile(saved, "w") as obj:
        for file in Path.cwd().glob("*.ipynb"):
            obj.write(file.name)
            print(f"Archived: {file.name}")
    print(f"Please summit this file at {saved}")


import numpy as np
from scipy.optimize import least_squares


def objective_diff(M_flatten, points_2d, points_3d, projection):
    M = np.reshape(np.append(M_flatten, 1), (3, 4))
    projected_2d_points = projection(M, points_3d)
    return -1 * (projected_2d_points.flatten() - points_2d.flatten())


def evaluate(M, points_2d, points_3d, projection):
    estimated_points_2d = projection(M, points_3d)
    residual = np.sum(
        np.hypot(
            estimated_points_2d[:, 0] - points_2d[:, 0],
            estimated_points_2d[:, 1] - points_2d[:, 1],
        )
    )
    print(f"residual error of L2(M*point_3d,point_2d):{residual}")


def estimate_M(projection, points_2d, points_3d, initial_guess):
    initial_guess = initial_guess.reshape(12, 1)[:-1].flatten()
    diff = least_squares(
        objective_diff,
        initial_guess,
        args=(points_2d, points_3d, projection),
        method="lm",
    )
    M = np.insert(diff.x, 11, 1, axis=0)
    M = M.reshape(3, 4)
    evaluate(M, points_2d, points_3d, projection)
    return M


import cv2


def point2patches(img, point):
    x_axis = np.linspace(-4, 4, num=8)
    y_axis = np.linspace(-4, 4, num=8)
    x_axis, y_axis = np.meshgrid(x_axis, y_axis)
    z = np.exp(-0.1 * x_axis ** 2 - 0.1 * y_axis ** 2)
    (x, y) = point
    region = img[y - 8 : y + 8, x - 8 : x + 8, :]
    patches = []
    for x, y in [(0, 0), (0, 1), (1, 0), (1, 1)]:
        sub_region = region[x * 8 : x * 8 + 8, y * 8 : y * 8 + 8]
        sub_region = cv2.cvtColor(sub_region, cv2.COLOR_RGB2GRAY)
        sub_region = (sub_region * z).astype(int)
        for x, y in [(0, 0), (0, 1), (1, 0), (1, 1)]:
            patch = sub_region[x * 4 : x * 4 + 4, y * 4 : y * 4 + 4]
            patches.append(patch)
    return region, patches


# def objective_MSE(M_flatten, points_2d, points_3d,projection):
#     M = np.reshape(np.append(M_flatten, 1), (3, 4))
#     return np.sum(np.square(projection(M, points_3d) - points_2d)) / points_2d.shape[0]

# def estimate_camera_matrix_2(points_2d, points_3d, initial_guess):
#     res = optimize.minimize(
#         objective_MSE, initial_guess, args=(points_2d, points_3d), method="SLSQP"
#     )
#     M = np.insert(res.x, 11, 1, axis=0)
#     M = M.reshape(3, 4)
#     return M

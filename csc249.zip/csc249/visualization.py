import numpy as np
import torch, pickle
import cv2

# from pathlib import Path
import matplotlib.pyplot as plt

# from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter

# import torch.nn.functional as F
# import torch.nn as nn
# import torch.utils.data as Data
# from tqdm.notebook import tqdm
def plot_3D(surface, X, Y, name="surface"):
    assert surface.shape[0] == len(
        Y
    ), "suface's length cannot match Y, use linespace to spcify number of samples."
    assert surface.shape[1] == len(
        X
    ), "suface's length cannot match X, use linespace to spcify number of samples"
    X, Y = np.meshgrid(X, Y)
    fig = plt.figure(figsize=(10, 10))
    ax = fig.gca(projection="3d")
    ax.set_title(name)
    surf = ax.plot_surface(X, Y, surface, cmap=cm.coolwarm, antialiased=False)
    fig.colorbar(surf, shrink=0.75, aspect=10, pad=0.1)

    # ax.zaxis.set_major_formatter(FormatStrFormatter('%.04f'))
    plt.show()


def show_camera_center(points_3d, camera_center):
    """
    Visualize the actual 3D points and the estimated 3D camera center.
    """
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection="3d")
    plt.subplots_adjust(left=0, bottom=0, right=1, top=1)
    ax.scatter(
        points_3d[:, 0],
        points_3d[:, 1],
        points_3d[:, 2],
        c="blue",
        marker="o",
        s=20,
        depthshade=0,
    )
    camera_center = camera_center.squeeze()
    ax.scatter(
        camera_center[0],
        camera_center[1],
        camera_center[2],
        c="red",
        s=50,
        depthshade=0,
    )
    min_z = min(points_3d[:, 2])
    for p in points_3d:
        x, y, z = p
        ax.plot3D(xs=[x, x], ys=[y, y], zs=[z, min_z], c="black", linewidth=1)
    x, y, z = camera_center


"""
Draw the displacement vectors on the image, given (u,v) and save it to the output filepath provided
"""


def plotFlow(frame, flow):
    U = flow["u"]
    V = flow["v"]
    line_color = (0, 255, 0)  #  Green

    for i in range(frame.shape[0]):
        for j in range(frame.shape[1]):
            u, v = U[i][j], V[i][j]

            if u and v:
                frame = cv2.arrowedLine(
                    frame,
                    (i, j),
                    (int(round(i + u)), int(round(j + v))),
                    (0, 255, 0),
                    thickness=1,
                )
    plt.imshow(frame)
